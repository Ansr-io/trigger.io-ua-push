//
//  main.m
//  ForgeInspector
//
//  Created by Connor Dunn on 26/07/2012.
//  Copyright (c) 2012 Trigger Corp. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([ForgeAppDelegate class]));
	}
}
